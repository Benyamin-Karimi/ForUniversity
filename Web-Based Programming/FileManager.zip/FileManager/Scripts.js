const ListButton = document.getElementById("ListButton");
const ReadOrWriteButton = document.getElementById("ReadOrWriteButton");
const AddButton = document.getElementById("AddButton");
const SearchButton = document.getElementById("SearchButton");
const CopyButton = document.getElementById("CopyButton");
const DeleteButton = document.getElementById("DeleteButton");
const SaveButton = document.getElementById("SaveButton");
const AllDeleteInCell = document.querySelectorAll("body > div > div:nth-child(3) > table > tbody > tr > td:nth-child(2) > input");
AllDeleteInCell.forEach(button => button?.addEventListener("click", function () { window.location.href = "FileManager.php?action=delete&filename=" + this.closest("tr").cells[0].textContent }));
ListButton?.addEventListener("click", function () { window.location.href = 'FileManager.php?action=list' });
const rows = document.querySelectorAll("body > div > div:nth-child(3) > table > tbody > tr > td:nth-child(1)");
rows.forEach(row => {
    row?.addEventListener("click", function () {
        rows.forEach(r => r.classList.remove("selected"));
        this.classList.add("selected");
    });
});
ReadOrWriteButton?.addEventListener("click", function () {
    const selectedRow = document.querySelector("td.selected");

    if (selectedRow) {
        const firstCellText = selectedRow.textContent;
        window.location.href = 'FileManager.php?action=rw&filename=' + firstCellText;
    } else {
        alert("Please select a file");
    }
});

CopyButton?.addEventListener("click", function () {

    const selectedRow = document.querySelector("td.selected");
    if (selectedRow) {
        const firstCellText = selectedRow.textContent;
        window.location.href = 'FileManager.php?action=copy&old=' + firstCellText + '&new=' + document.getElementById("FileName").value;
    } else {
        alert("Please select a file");
    }
});

AddButton?.addEventListener("click", function () {
    window.location.href = 'FileManager.php?action=add&filename=' + document.getElementById("FileName").value;
});

DeleteButton?.addEventListener("click", function () {
    window.location.href = 'FileManager.php?action=delete&filename=' + document.getElementById("FileName").value;
});

SearchButton?.addEventListener("click", function () {
    window.location.href = 'FileManager.php?action=search&filename=' + document.getElementById("FileName").value;
});

SaveButton?.addEventListener("click", function () {
    window.location.href = 'FileManager.php?action=save&filename=' + new URLSearchParams(window.location.search).get("filename") + "&content=" + document.getElementById("Editor").value;
});
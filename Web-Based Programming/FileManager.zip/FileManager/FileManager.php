<?php
    require("Logics\Classes.php");
    $FM = new FileManager();
?>
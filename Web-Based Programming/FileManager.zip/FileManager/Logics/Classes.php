<?php
class References
{
    public $PageTitle;
    function __construct()
    {
        $this->GenerateHeader();
    }
    function GenerateHeader()
    {
        echo
            "
            <head>
            <meta charset='UTF-8'>
            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
            <title>$this->PageTitle</title>
            <link href='Styles\Styles.css' rel='stylesheet' />
            </head>
            ";
    }
}

class File
{
    public static function GetAllFiles($directory)
    {
        return array_diff(scandir($directory), array('..', '.'));
    }
    public static function CreateFile($directory)
    {
        $file = fopen($directory, 'w');
        fwrite($file, "");
        fclose($file);
    }
    public static function DeleteFile($directory)
    {
        unlink($directory);
    }
    public static function CopyFile($directory, $newName)
    {
        copy($directory, $newName);
    }
    public static function WriteFile($directory, $content)
    {
        $file = fopen($directory, 'w');
        fwrite($file, $content);
        fclose($file);
    }
    public static function ReadFile($directory): string
    {
        return file_get_contents($directory);
    }
    public static function IsExist($directory)
    {
        return file_exists($directory);
    }
}

class FileManager extends References
{

    function __construct()
    {
        $this->PageTitle = "File Manager";
        parent::__construct();
        $this->GenerateBody();
        if (empty($_GET)) {
            header("Location: FileManager.php?action=list");
        }
    }

    function GenerateBody()
    {
        switch (strtolower($_GET["action"])) {
            case "list":
                echo '<body><div class="Container"><div id="filenamecontrols"><label for="FileName">File name:</label><input id="FileName" type="text" /></div><div class="Controls"><input type="button" id="AddButton" value="Add" /><input type="button" id="ReadOrWriteButton" value="Read or Write"/><input type="button" id="CopyButton" value="Copy"/><input type="button" id="ListButton" value="List"/><input type="button" id="SearchButton" value="Search"/><input type="button" id="DeleteButton" value="Delete"/></div><div class="Workspace">';
                $Files = File::GetAllFiles("Workspace");
                echo '<table class="Table" border="1" cellpadding="10" cellspacing="0"><thead><tr><th>File name</th><th>Delete</th></tr></thead><tbody>';
                foreach ($Files as $File) {
                    echo '<tr><td>' . $File . '</td><td><input type="button" id="DeleteInCell" value="Delete"/></td></tr>';
                }
                echo '</tbody></table>';
                echo '</div></body><script src="Scripts.js"></script>';
                break;
            case "add": {
                File::CreateFile("./Workspace/" . $_GET["filename"]);
                header("Location: FileManager.php?action=list");
                break;
            }
            case "delete": {
                File::DeleteFile("./Workspace/" . $_GET["filename"]);
                header("Location: FileManager.php?action=list");
                break;
            }
            case "copy": {
                File::CopyFile("./Workspace/" . $_GET["old"], "./Workspace/" . $_GET["new"]);
                header("Location: FileManager.php?action=list");
                break;
            }
            case "rw": {
                echo '<body><div class="Container"><label id="EditOn">' . $_GET["filename"] . '</label><textarea id="Editor">' . File::ReadFile("./Workspace/" . $_GET["filename"]) . '</textarea><input type="button" id="SaveButton" value="Save"></div></div></body><script src="Scripts.js"></script>';
                break;
            }
            case "save": {
                File::WriteFile("./Workspace/" . $_GET["filename"], $_GET["content"]);
                header("Location: FileManager.php?action=list");
                break;
            }
            case "search": {
                $IsExist = File::IsExist("./Workspace/" . $_GET["filename"]);

                echo '<body>

    <div class="Container">
        <div style='.(($IsExist) ? "\"background-color: #592EE5;\"" : "\"background-color: #F44336;\"").'id="RoE">'.(($IsExist) ? $_GET["filename"]. " is Exist." : $_GET["filename"]. " is not Exist.").'</div>
        <input type="button" id="Back" value="back" onclick="window.location.href='."'FileManager.php?action=list'".'">
    </div>
</body>
<script src="Scripts.js"></script>';

                break;
            }
        }
    }
}
?>